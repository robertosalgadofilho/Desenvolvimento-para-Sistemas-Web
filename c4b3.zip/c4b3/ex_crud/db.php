<?php
    $hn = 'localhost';
    $db = 'publicacoes';
    $un = 'root';
    $pw = '';
?>

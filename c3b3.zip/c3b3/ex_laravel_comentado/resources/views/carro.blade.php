<!doctype html>
<html lang="pt-br">

<head>
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <!-- FONTAWESOME ICONS-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <title>Sistema Garagem de Carros</title>
</head>

<body>

  <div class="container">
   
   @include("header") <!-- INCLUI O ARQUIVO HEADER.BLADE.PHP -->

  <!--DIRETIVA DE CONDIÇÃO que
   -->
   @if($layout == 'index')
     <div class="row">       
         @include("carrolista")<!--inclui o arquivo carrolista.blade.php -->  
     </div>
  
  <!-- Se o valor na variável $layout for create, será incluido o conteúdo
  que está no arquivo carrocadastro.blade.php -->
   @elseif($layout == 'create')  
     <div class="row">
        @include('carrocadastro')<!-- inclui o arquivo carrocadastro.blade.php -->
     </div>
   
   <!-- e o valor na variável $layout for edit, será incluido o conteúdo
  que está no arquivo carroatualiza.blade.php -->
   @elseif($layout == 'edit')
    <div class="row">
      @include("carroatualiza")<!-- inclui o arquivo carroatualiza.blade.php -->
    </div>
  
   @endif<!-- FIM DA CONDIÇÃO -->

  </div>

  
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
    integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
    integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
    crossorigin="anonymous"></script>
</body>

</html>
<section class="col">
    <!--MOSTRA A IMAGEM DA PÁGINA DE CRIAR-->
    <img src="https://dinheirama.com/wp-content/uploads/2015/05/20150513-dinheirama-carro-concessionaria-720x350.jpg"
        class="card-img-top" alt="...">
    <h4 cla>Atualize ao lado o carro já inserido</h4>
</section>

<section class="col">
    <!-- Gera a ação que formulário dinâmico quando for atualizar baseando-se no ID passado -->
    <form action="{{ url('/update/'.$carro->id) }}" method="post">

        @csrf <!-- Proteção contra ataques -->

        <div class="form-group">
            <label>Modelo</label>
            <!-- carrega como value do input o nome do modelo baseado no id -->
            <input value="{{ $carro->modelo }}" name="modelo" type="text" class="form-control">
        </div>

        <div class="form-group">
            <label>Marca</label>
            <!-- carrega como value do input a marca vindo no objeto carro -->
            <input value="{{ $carro->marca }}" name="marca" type="text" class="form-control">
        </div>

        <div class="form-group">
            <label>Ano</label>
            <!-- carrega como value do input o ano vindo no objeto carro -->
            <input value="{{ $carro->ano }}" name="ano" type="text" class="form-control">
        </div>

        <div class="form-group">
            <label>Preço</label>
            <!-- carrega como value do input o preço vindo no objeto carro -->
            <input value="{{ $carro->preco }}" name="preco" type="text" class="form-control">
        </div>

        <div class="form-group">
            <label>Quantidade de portas</label>
            <!-- carrega como value do input a quantidade de portas vindas no objeto carro -->
            <input value="{{ $carro->qtd_porta }}" name="qtd_porta" type="text" class="form-control">
        </div>
        <input type="submit" value="Atualizar" class="btn btn-info">
    </form>
</section>
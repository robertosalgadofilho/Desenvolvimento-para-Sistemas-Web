<section class="col">
<div class="card mb-3">
  <img src="https://dinheirama.com/wp-content/uploads/2015/05/20150513-dinheirama-carro-concessionaria-720x350.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Listagem de carros</h5>
    <p class="card-text"> Confira todos os modelos disponíveis no estoque da loja.</p>
  
  <table class="table text-center">
    <thead class="thead-light">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Modelo</th>
            <th scope="col">Marca</th>
            <th scope="col">Ano</th>
            <th scope="col">Preço</th>
            <th scope="col">Portas</th>
            <th scope="col">Ações</th>
        </tr>
    </thead>
    <tbody>
        <!-- Faz um laço dentro do objeto $todosCarros. 
            Cada iteração a variavel $value recebe a posição atual do elemento
         -->
        @foreach($todosCarros as $value)
            <tr>
                <!-- {{ Posição no array -> dado que procura }} -->
                <td>{{$value->id}}</td>
                <td>{{$value->modelo }}</td>
                <td>{{$value->marca }}</td>
                <td>{{$value->ano }}</td>
                <td>R${{$value->preco }}</td>
                <td>{{$value->qtd_porta}}</td>
                <td>
                            <!-- O href do link envia para url o verbo edit com o valor do id carro -->
                    <a href="{{url('/edit/'.$value->id)}}" class="btn btn-sm btn-warning" data-toggle="tooltip" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                    
                            <!-- O href do link envia para url o verbo delete com o valor do id carro -->
                    <a href="{{url('/delete/'.$value->id)}}" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Deletar"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
  </div>
</div>

</section>
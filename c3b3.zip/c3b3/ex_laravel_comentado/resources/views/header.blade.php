<div class="py-5 text-center">
  <h2>Sistema Garagem de Carros</h2>
  <p class="lead">

    <!-- O href do link envia para a pagina home -->
    <a href="{{url('/')}}" data-toggle="tooltip" title="Index">Home</a> 
    
    <!-- O href do link envia para a página de cadastro -->
    <a href="{{url('/create')}}" data-toggle="tooltip" title="Index">Novo cadastro</a> </p>
</div>
<?php

namespace App\Http\Controllers;

use App\Carro;
use Illuminate\Http\Request;


/**Classe responsável por trazer as informações do banco de dados e
* retornar uma view
* comando > php artisan make:controller CarroController --resource
*/ 
class CarroController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $todosCarros = Carro::all();
        return view('carro',[
            'todosCarros'=>$todosCarros,
            'layout' => 'index'
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $todosCarros = Carro::all();
        return view('carro', 
            [
                'todosCarros'=>$todosCarros, 
                'layout'=>'create'
            ]
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $carro = new Carro();
        $carro->modelo = $request->input('modelo');
        $carro->marca = $request->input('marca');
        $carro->ano = $request->input('ano');
        $carro->preco = $request->input('preco');
        $carro->qtd_porta = $request->input('qtd_porta');
        $carro->save();
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $carro = Carro::find($id);
        $todosCarros = Carro::all();
        return view('carro', [
            'todosCarros'=> $todosCarros,
            'carro' => $carro,
            'layout'=> 'show'
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $carro = Carro::find($id);
        $todosCarros = Carro::all();
        return view('carro', [
            'todosCarros'=> $todosCarros,
            'carro' => $carro,
            'layout'=> 'edit'
        ]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $carro = Carro::find($id);
        $carro->modelo = $request->input('modelo');
        $carro->marca = $request->input('marca');
        $carro->ano = $request->input('ano');
        $carro->preco = $request->input('preco');
        $carro->qtd_porta = $request->input('qtd_porta');
        $carro->save();
        return redirect('/');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $carro = Carro::find($id);
        $carro->delete();
        return redirect('/');
    }
}

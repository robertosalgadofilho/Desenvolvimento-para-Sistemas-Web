<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Carro extends Model
{
    // cria um model e protege o nome da tabela
    // comando > php artisan make:model Carro
    protected $table = 'carro';
}

  <section class="col">
    <!--MOSTRA A IMAGEM DA PÁGINA DE CRIAR-->
    <img src="https://dinheirama.com/wp-content/uploads/2015/05/20150513-dinheirama-carro-concessionaria-720x350.jpg" class="card-img-top" alt="...">
    <h4 cla>Atualize ao lado o carro já inserido</h4>
</section>


<section class="col">
    <form action="<?php echo e(url('/update/'.$carro->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Modelo</label>
        <input value="<?php echo e($carro->modelo); ?>" name="modelo" type="text" class="form-control">
    </div>

    <div class="form-group">
        <label>Marca</label>
        <input value="<?php echo e($carro->marca); ?>" name="marca" type="text" class="form-control">
    </div>

    <div class="form-group">
        <label>Ano</label>
        <input value="<?php echo e($carro->ano); ?>" name="ano" type="text" class="form-control">
    </div>

     <div class="form-group">
        <label>Preço</label>
        <input value="<?php echo e($carro->preco); ?>" name="preco" type="text" class="form-control">
    </div>

    <div class="form-group">
        <label>Quantidade de portas</label>
        <input value="<?php echo e($carro->qtd_porta); ?>" name="qtd_porta" type="text" class="form-control">
    </div>
    <input type="submit" value="Atualizar" class="btn btn-info">

    </form>
</section><?php /**PATH C:\Users\dnlo\Desktop\ex_laravel\resources\views/carroatualiza.blade.php ENDPATH**/ ?>
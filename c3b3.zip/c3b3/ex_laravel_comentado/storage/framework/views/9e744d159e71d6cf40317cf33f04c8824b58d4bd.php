  <section class="col">
    <!--MOSTRA A IMAGEM DA PÁGINA DE CRIAR-->
    <img src="https://dinheirama.com/wp-content/uploads/2015/05/20150513-dinheirama-carro-concessionaria-720x350.jpg" class="card-img-top" alt="...">
    <h4 cla>Cadastre ao lado o novo carro</h4>
</section>

<section class="col">
    <form action="<?php echo e(url('/store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label>Modelo</label>
        <input name="modelo" type="text" class="form-control" placeholder="">
    </div>

    <div class="form-group">
        <label>Marca</label>
        <input name="marca" type="text" class="form-control" placeholder="">
    </div>

    <div class="form-group">
        <label>Ano</label>
        <input name="ano" type="text" class="form-control" placeholder="">
    </div>

    <div class="form-group">
    <label>Preço</label>
    <input name="preco" type="text" class="form-control" placeholder="">
    </div>

    <div class="form-group">
        <label>Quantidade de portas</label>
        <input name="qtd_porta" type="text" class="form-control" placeholder="">
    </div>
    <input type="submit" value="Salvar" class="btn btn-info">
    <input type="reset" value="Resetar" class="btn btn-warning">

    </form>
</section><?php /**PATH C:\Users\dnlo\Desktop\ex_laravel\resources\views/carrocadastro.blade.php ENDPATH**/ ?>
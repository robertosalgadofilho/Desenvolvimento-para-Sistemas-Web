
 <div class="py-5 text-center">
  <h2>Sistema Garagem de Carros</h2>
  <p class="lead">
    <a href="<?php echo e(url('/')); ?>" data-toggle="tooltip" title="Index">Home</a> | 
    <a href="<?php echo e(url('/create')); ?>" data-toggle="tooltip" title="Index">Novo cadastro</a> </p>
</div><?php /**PATH C:\Users\dnlo\Desktop\ex_laravel\resources\views/header.blade.php ENDPATH**/ ?>
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


/**
 *  As migrations gera as tabelas do banco de dados 
 * comando para CRIAR O ARQUIVO> php artisan make:migration create_carro
 * comando para CRIAR AS TABELAS DENTRO do banco de dados > php artisan migrate
 */

class CreateCarro extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('carro', function (Blueprint $table) {
            $table->id()->index();
            $table->string('modelo');
            $table->string('marca');
            $table->integer('ano');
            $table->decimal('preco', 8, 2);
            $table->integer('qtd_porta');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carro');
    }
}

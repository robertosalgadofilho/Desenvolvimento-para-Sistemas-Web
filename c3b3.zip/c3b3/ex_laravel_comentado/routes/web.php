<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/**
 * Quando a rota for a primeira, ou seja a home
 * envia para o controller a instrução index
 */
Route::get('/', 'CarroController@index');

/**
 * Edit é a uri do endereço da página
 * {id} é passado via get o id do usuário
 */
Route::get('/edit/{id}','CarroController@edit');

/**
 * Quando a rota for para criar um novo cadastro,
 * envia para o controller a instrução create
 */
Route::get('/create','CarroController@create');


/**
 * Delete é a uri do endereço da página
 * {id} é passado via get o id do usuário
 */
Route::get('/delete/{id}','CarroController@destroy');

/**
 * store(salvar) é a uri do endereço da página
 */
Route::post('/store','CarroController@store');

/**
 * update é a uri do endereço da página
 * {id} é passado via get o id do usuário
 */
Route::post('/update/{id}','CarroController@update');

